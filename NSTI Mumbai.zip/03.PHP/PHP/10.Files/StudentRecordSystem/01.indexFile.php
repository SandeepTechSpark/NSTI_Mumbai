
<?php
echo "<b>";
echo"<h2>Student Record System</h2>";
echo "<a href='addFile.php'>01.Add File</a><br><br>";
echo "<a href='viewFile.php'>02.View File</a><br><br>";
echo "<a href='deleteFile.php'>03.Delete Student Record</a><br><br>";
echo "<center>";

echo "</65center>";
echo "</b>";
?>
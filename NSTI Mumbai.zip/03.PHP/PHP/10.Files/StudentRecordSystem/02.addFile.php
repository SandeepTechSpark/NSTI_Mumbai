<?php
$message="";
if(isset($_POST['submit'])){
				
}
?>
<br><br><br>
<button onclick='back.history()'>Back</button>
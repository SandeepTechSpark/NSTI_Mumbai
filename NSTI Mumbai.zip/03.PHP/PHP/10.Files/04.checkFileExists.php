<?php
if(file_exists('sample.txt')) echo "<h2>File Exists.</h2>";
else echo "<h2>File Not found.</h2>";
?>
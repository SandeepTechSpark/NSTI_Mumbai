<?php
if(file_exists('sample.txt')) {
				$file = fopen('sample.txt','a');
				$text = "\n This is new appended line";
				fwrite($file,$text);
				fclose($file);
				echo "<h2>Data appended successfully.</h2>";
} else echo "<h2>Sorry! File not found";
?>
<?php
// Consolidated Program (Create, Write, Read, Append & Check Existance etc.)


// 01. Create and Write file
$file = fopen('abc.txt','w');
$text = 'Hello, this is PHP file handling.';
fwrite($file,$text);
fclose($file);
echo "<h3>file created! and data written \n";

// 02. Append Data to file
$file = fopen('abc.txt','a');
$appendText ='This line is appended.'.'<br>';
fwrite($file,$appendText);
fclose($file);
echo "<h3>Data appended successfully.\n";

// 03. Read File Content
echo "<h3>File Content : <br>";
if(file_exists('abc.txt')) {
				$file = fopen('abc.txt','r');
				while(!feof($file)) {
								$content = fgets($file);
								echo "<h4>".$content."</h4>";
				} fclose($file);
				echo "<br>";
} else echo "<h3>File not found!</h3>";

// 05. Check file exists of server
if(file_exists('abc.txt')) {
				echo "<h3>File Exists on Server";
} else echo "File no found!";
?>
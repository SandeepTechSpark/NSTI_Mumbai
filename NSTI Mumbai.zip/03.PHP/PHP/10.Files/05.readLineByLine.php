<?php
$file = fopen('sample.txt','r');
while(!feof($file)) {
				$line = fgets($file);
				echo "<h3>".$line."</h3><br>";
} fclose($file);
?>
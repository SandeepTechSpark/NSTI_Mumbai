<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>areaOfTriangle</title>
</head>
<body>
  <h1>Area of Triangle having three different sides</h1><hr>
  <form method="post" action="">
    <table border='2' width='100%'>
      <tr bgcolor='lightgreen'><th align='center' colspan="2">Area of Triangle</th></tr>
      <tr><th><label for="a">First Side (A)</label></th><th><input type='number' id='a' name='a' placeholder="Enter the first side value"</th></tr>
        <tr><th><label for="b">Second Side (B)</label></th><th><input type='number' id='b' name='b' placeholder="Enter the Second side value"</th></tr>
          <tr><th><label for="c">Third Side (C)</label></th><th><input type='number' id='c' name='c' placeholder="Enter the first side value"</th></tr>
    </table>
           <center> <br> <input type="submit" name="submit" value="Calculate Factorial"> &nbsp;&nbsp;&nbsp; <input type="reset" value="Clear"><hr> </center>
  </form>
    
    <?php
    // for checking the submit button is clicked or not?
    if(isset($_POST['submit'])) {
      // To Take Input from user
      $a=$_POST['a']; // First Side Value
    $b=$_POST['b']; 				// Second Side Value
    $c=$_POST['c']; 				// Third Side Value
				// To find the Semi-Perimeter
												$s=($a+$b+$c)/2;
												echo "<hr> Semi-Perimeter : ".$s;
				// Process to Find Area Using Heron's formula
												$area=sqrt($s*($s-$a)*($s-$b)*($s-$c));
												echo"<hr>Area of Triangle : ".$area.'<hr>';
    }
?>
</body>
</html>